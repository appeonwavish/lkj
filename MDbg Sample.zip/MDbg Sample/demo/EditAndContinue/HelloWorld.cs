using System;
public class HelloWorld {
	public static void Main()
	{
		Console.Write("Hello, ");
		PrintWorld();
	}

	static void PrintWorld()
	{
		Console.WriteLine("World");
	}
}
