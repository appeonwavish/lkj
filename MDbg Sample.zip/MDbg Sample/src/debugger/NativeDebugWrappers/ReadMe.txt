//---------------------------------------------------------------------
//  This file is part of the CLR Managed Debugger (mdbg) Sample.
// 
//  Copyright (C) Microsoft Corporation.  All rights reserved.
//---------------------------------------------------------------------

ReadMe.txt for NativeDebugWrappers project.

The library NativeDebugWrappers can be used to write a native debugger 
in managed code. It complements the CorApi library that allows writing
managed debuggers in managed code. 