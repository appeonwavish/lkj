// Assembly attributes for MDbg Extension interfaces

using System;
using System.Collections;
using System.Diagnostics;
using System.Text;
using System.Reflection;
using System.Runtime.Serialization;
using System.Security.Permissions;

[assembly:CLSCompliant(true)]
[assembly:System.Runtime.InteropServices.ComVisible(false)]
[assembly:SecurityPermission(SecurityAction.RequestMinimum, Unrestricted=true)]