//---------------------------------------------------------------------
//  This file is part of the CLR Managed Debugger (mdbg) Sample.
// 
//  Copyright (C) Microsoft Corporation.  All rights reserved.
//---------------------------------------------------------------------

ReadMe.txt for mdbgext project.

This project has interfaces allowing users to extend mdbg executable with custom commands. The command can be written as separate assemblies and loaded into debugger with mdbg's "load" command.
This solution comes with three extensions (enc, gui, and ildasm), but feel free to write your own.
