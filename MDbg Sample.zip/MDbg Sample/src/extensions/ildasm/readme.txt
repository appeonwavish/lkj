//---------------------------------------------------------------------
//  This file is part of the CLR Managed Debugger (mdbg) Sample.
// 
//  Copyright (C) Microsoft Corporation.  All rights reserved.
//---------------------------------------------------------------------

ReadMe.txt for ildasm project.

This is a loadable extension.  Type "load ildasm" in mdbg to get this functionality.

It allows for stepping on the IL level and printing IL code instead of source code.