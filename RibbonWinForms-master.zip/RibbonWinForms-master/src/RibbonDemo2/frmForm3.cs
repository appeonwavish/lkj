﻿using System.Windows.Forms;

namespace RibbonDemo2
{
    public partial class frmForm3 : Form
    {
        public frmForm3()
        {
            InitializeComponent();
        }
    }
}
