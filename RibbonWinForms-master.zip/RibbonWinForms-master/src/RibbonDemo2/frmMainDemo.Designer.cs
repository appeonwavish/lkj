﻿using System.ComponentModel;
using System.Windows.Forms;

namespace RibbonDemo2
{
    partial class frmMainDemo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMainDemo));
            this.ribbon1 = new System.Windows.Forms.Ribbon();
            this.ribbonOrbMenuItem9 = new System.Windows.Forms.RibbonOrbMenuItem();
            this.ribbonOrbMenuItem10 = new System.Windows.Forms.RibbonOrbMenuItem();
            this.ribbonOrbMenuItem11 = new System.Windows.Forms.RibbonOrbMenuItem();
            this.ribbonOrbMenuItem12 = new System.Windows.Forms.RibbonOrbMenuItem();
            this.ribbonButton15 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton16 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton17 = new System.Windows.Forms.RibbonButton();
            this.ribbonSeparator2 = new System.Windows.Forms.RibbonSeparator();
            this.ribbonButton18 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton19 = new System.Windows.Forms.RibbonButton();
            this.ribbonTab1 = new System.Windows.Forms.RibbonTab();
            this.ribbonPanel3 = new System.Windows.Forms.RibbonPanel();
            this.btForm1 = new System.Windows.Forms.RibbonButton();
            this.btForm2 = new System.Windows.Forms.RibbonButton();
            this.btForm3 = new System.Windows.Forms.RibbonButton();
            this.ribbonPanel_OrbStyle = new System.Windows.Forms.RibbonPanel();
            this.ribbonPanel_Theme = new System.Windows.Forms.RibbonPanel();
            this.ribbonTab2 = new System.Windows.Forms.RibbonTab();
            this.ribbonOrbMenuItem1 = new System.Windows.Forms.RibbonOrbMenuItem();
            this.ribbonOrbMenuItem2 = new System.Windows.Forms.RibbonOrbMenuItem();
            this.ribbonOrbMenuItem3 = new System.Windows.Forms.RibbonOrbMenuItem();
            this.ribbonOrbMenuItem4 = new System.Windows.Forms.RibbonOrbMenuItem();
            this.ribbonOrbMenuItem5 = new System.Windows.Forms.RibbonOrbMenuItem();
            this.ribbonOrbMenuItem6 = new System.Windows.Forms.RibbonOrbMenuItem();
            this.ribbonSeparator1 = new System.Windows.Forms.RibbonSeparator();
            this.ribbonOrbMenuItem7 = new System.Windows.Forms.RibbonOrbMenuItem();
            this.ribbonOrbMenuItem8 = new System.Windows.Forms.RibbonOrbMenuItem();
            this.ribbonOrbRecentItem1 = new System.Windows.Forms.RibbonOrbRecentItem();
            this.ribbonOrbRecentItem2 = new System.Windows.Forms.RibbonOrbRecentItem();
            this.ribbonOrbRecentItem3 = new System.Windows.Forms.RibbonOrbRecentItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // ribbon1
            // 
            this.ribbon1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ribbon1.Location = new System.Drawing.Point(0, 0);
            this.ribbon1.Minimized = false;
            this.ribbon1.Name = "ribbon1";
            // 
            // 
            // 
            this.ribbon1.OrbDropDown.AllowDrop = true;
            this.ribbon1.OrbDropDown.BorderRoundness = 8;
            this.ribbon1.OrbDropDown.Location = new System.Drawing.Point(0, 0);
            this.ribbon1.OrbDropDown.MenuItems.Add(this.ribbonOrbMenuItem9);
            this.ribbon1.OrbDropDown.MenuItems.Add(this.ribbonOrbMenuItem10);
            this.ribbon1.OrbDropDown.MenuItems.Add(this.ribbonOrbMenuItem11);
            this.ribbon1.OrbDropDown.MenuItems.Add(this.ribbonOrbMenuItem12);
            this.ribbon1.OrbDropDown.Name = "";
            this.ribbon1.OrbDropDown.OptionItems.Add(this.ribbonButton15);
            this.ribbon1.OrbDropDown.OptionItems.Add(this.ribbonButton16);
            this.ribbon1.OrbDropDown.OptionItems.Add(this.ribbonButton17);
            this.ribbon1.OrbDropDown.OptionItems.Add(this.ribbonSeparator2);
            this.ribbon1.OrbDropDown.OptionItems.Add(this.ribbonButton18);
            this.ribbon1.OrbDropDown.OptionItems.Add(this.ribbonButton19);
            this.ribbon1.OrbDropDown.Size = new System.Drawing.Size(527, 248);
            this.ribbon1.OrbDropDown.TabIndex = 0;
            this.ribbon1.OrbText = "File";
            this.ribbon1.RibbonTabFont = new System.Drawing.Font("Trebuchet MS", 9F);
            this.ribbon1.Size = new System.Drawing.Size(944, 144);
            this.ribbon1.TabIndex = 0;
            this.ribbon1.Tabs.Add(this.ribbonTab1);
            this.ribbon1.Tabs.Add(this.ribbonTab2);
            this.ribbon1.TabsMargin = new System.Windows.Forms.Padding(12, 26, 20, 0);
            this.ribbon1.Text = "ribbon1";
            // 
            // ribbonOrbMenuItem9
            // 
            this.ribbonOrbMenuItem9.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonOrbMenuItem9.Image = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem9.Image")));
            this.ribbonOrbMenuItem9.LargeImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem9.LargeImage")));
            this.ribbonOrbMenuItem9.Name = "ribbonOrbMenuItem9";
            this.ribbonOrbMenuItem9.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem9.SmallImage")));
            this.ribbonOrbMenuItem9.Text = "ribbonOrbMenuItem9";
            // 
            // ribbonOrbMenuItem10
            // 
            this.ribbonOrbMenuItem10.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonOrbMenuItem10.Image = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem10.Image")));
            this.ribbonOrbMenuItem10.LargeImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem10.LargeImage")));
            this.ribbonOrbMenuItem10.Name = "ribbonOrbMenuItem10";
            this.ribbonOrbMenuItem10.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem10.SmallImage")));
            this.ribbonOrbMenuItem10.Text = "ribbonOrbMenuItem10";
            // 
            // ribbonOrbMenuItem11
            // 
            this.ribbonOrbMenuItem11.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonOrbMenuItem11.Image = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem11.Image")));
            this.ribbonOrbMenuItem11.LargeImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem11.LargeImage")));
            this.ribbonOrbMenuItem11.Name = "ribbonOrbMenuItem11";
            this.ribbonOrbMenuItem11.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem11.SmallImage")));
            this.ribbonOrbMenuItem11.Text = "ribbonOrbMenuItem11";
            // 
            // ribbonOrbMenuItem12
            // 
            this.ribbonOrbMenuItem12.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonOrbMenuItem12.Image = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem12.Image")));
            this.ribbonOrbMenuItem12.LargeImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem12.LargeImage")));
            this.ribbonOrbMenuItem12.Name = "ribbonOrbMenuItem12";
            this.ribbonOrbMenuItem12.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem12.SmallImage")));
            this.ribbonOrbMenuItem12.Text = "ribbonOrbMenuItem12";
            // 
            // ribbonButton15
            // 
            this.ribbonButton15.Image = global::RibbonDemo2.Properties.Resources.save32;
            this.ribbonButton15.LargeImage = global::RibbonDemo2.Properties.Resources.save32;
            this.ribbonButton15.Name = "ribbonButton15";
            this.ribbonButton15.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton15.SmallImage")));
            this.ribbonButton15.Text = "Save";
            // 
            // ribbonButton16
            // 
            this.ribbonButton16.Image = global::RibbonDemo2.Properties.Resources.newdocument32;
            this.ribbonButton16.LargeImage = global::RibbonDemo2.Properties.Resources.newdocument32;
            this.ribbonButton16.Name = "ribbonButton16";
            this.ribbonButton16.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton16.SmallImage")));
            this.ribbonButton16.Text = "New";
            // 
            // ribbonButton17
            // 
            this.ribbonButton17.Image = global::RibbonDemo2.Properties.Resources.open32;
            this.ribbonButton17.LargeImage = global::RibbonDemo2.Properties.Resources.open32;
            this.ribbonButton17.Name = "ribbonButton17";
            this.ribbonButton17.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton17.SmallImage")));
            this.ribbonButton17.Text = "Open";
            // 
            // ribbonSeparator2
            // 
            this.ribbonSeparator2.Name = "ribbonSeparator2";
            // 
            // ribbonButton18
            // 
            this.ribbonButton18.Image = global::RibbonDemo2.Properties.Resources.print32;
            this.ribbonButton18.LargeImage = global::RibbonDemo2.Properties.Resources.print32;
            this.ribbonButton18.Name = "ribbonButton18";
            this.ribbonButton18.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton18.SmallImage")));
            this.ribbonButton18.Text = "Print";
            // 
            // ribbonButton19
            // 
            this.ribbonButton19.Image = global::RibbonDemo2.Properties.Resources.close32;
            this.ribbonButton19.LargeImage = global::RibbonDemo2.Properties.Resources.close32;
            this.ribbonButton19.Name = "ribbonButton19";
            this.ribbonButton19.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton19.SmallImage")));
            this.ribbonButton19.Text = "Close";
            // 
            // ribbonTab1
            // 
            this.ribbonTab1.Name = "ribbonTab1";
            this.ribbonTab1.Panels.Add(this.ribbonPanel3);
            this.ribbonTab1.Panels.Add(this.ribbonPanel_OrbStyle);
            this.ribbonTab1.Panels.Add(this.ribbonPanel_Theme);
            this.ribbonTab1.Text = "Start";
            // 
            // ribbonPanel3
            // 
            this.ribbonPanel3.Items.Add(this.btForm1);
            this.ribbonPanel3.Items.Add(this.btForm2);
            this.ribbonPanel3.Items.Add(this.btForm3);
            this.ribbonPanel3.Name = "ribbonPanel3";
            this.ribbonPanel3.Text = "Open Form";
            // 
            // btForm1
            // 
            this.btForm1.Image = global::RibbonDemo2.Properties.Resources.newdocument32;
            this.btForm1.LargeImage = global::RibbonDemo2.Properties.Resources.newdocument32;
            this.btForm1.Name = "btForm1";
            this.btForm1.SmallImage = ((System.Drawing.Image)(resources.GetObject("btForm1.SmallImage")));
            this.btForm1.Text = "Form1";
            this.btForm1.Click += new System.EventHandler(this.btForm1_Click);
            // 
            // btForm2
            // 
            this.btForm2.Image = global::RibbonDemo2.Properties.Resources.printpreview32;
            this.btForm2.LargeImage = global::RibbonDemo2.Properties.Resources.printpreview32;
            this.btForm2.Name = "btForm2";
            this.btForm2.SmallImage = ((System.Drawing.Image)(resources.GetObject("btForm2.SmallImage")));
            this.btForm2.Text = "Form2";
            this.btForm2.Click += new System.EventHandler(this.btForm2_Click);
            // 
            // btForm3
            // 
            this.btForm3.Image = global::RibbonDemo2.Properties.Resources.worddocument32;
            this.btForm3.LargeImage = global::RibbonDemo2.Properties.Resources.worddocument32;
            this.btForm3.Name = "btForm3";
            this.btForm3.SmallImage = ((System.Drawing.Image)(resources.GetObject("btForm3.SmallImage")));
            this.btForm3.Text = "Form3";
            this.btForm3.Click += new System.EventHandler(this.btForm3_Click);
            // 
            // ribbonPanel_OrbStyle
            // 
            this.ribbonPanel_OrbStyle.Name = "ribbonPanel_OrbStyle";
            this.ribbonPanel_OrbStyle.Text = "Orb Style";
            // 
            // ribbonPanel_Theme
            // 
            this.ribbonPanel_Theme.Name = "ribbonPanel_Theme";
            this.ribbonPanel_Theme.Text = "Theme";
            // 
            // ribbonTab2
            // 
            this.ribbonTab2.Name = "ribbonTab2";
            this.ribbonTab2.Text = "Ribbon Tab 2";
            // 
            // ribbonOrbMenuItem1
            // 
            this.ribbonOrbMenuItem1.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonOrbMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem1.Image")));
            this.ribbonOrbMenuItem1.LargeImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem1.LargeImage")));
            this.ribbonOrbMenuItem1.Name = "ribbonOrbMenuItem1";
            this.ribbonOrbMenuItem1.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem1.SmallImage")));
            this.ribbonOrbMenuItem1.Text = "ribbonOrbMenuItem1";
            // 
            // ribbonOrbMenuItem2
            // 
            this.ribbonOrbMenuItem2.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonOrbMenuItem2.Image = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem2.Image")));
            this.ribbonOrbMenuItem2.LargeImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem2.LargeImage")));
            this.ribbonOrbMenuItem2.Name = "ribbonOrbMenuItem2";
            this.ribbonOrbMenuItem2.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem2.SmallImage")));
            this.ribbonOrbMenuItem2.Text = "ribbonOrbMenuItem2";
            // 
            // ribbonOrbMenuItem3
            // 
            this.ribbonOrbMenuItem3.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonOrbMenuItem3.Image = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem3.Image")));
            this.ribbonOrbMenuItem3.LargeImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem3.LargeImage")));
            this.ribbonOrbMenuItem3.Name = "ribbonOrbMenuItem3";
            this.ribbonOrbMenuItem3.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem3.SmallImage")));
            this.ribbonOrbMenuItem3.Text = "ribbonOrbMenuItem3";
            // 
            // ribbonOrbMenuItem4
            // 
            this.ribbonOrbMenuItem4.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonOrbMenuItem4.Image = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem4.Image")));
            this.ribbonOrbMenuItem4.LargeImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem4.LargeImage")));
            this.ribbonOrbMenuItem4.Name = "ribbonOrbMenuItem4";
            this.ribbonOrbMenuItem4.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem4.SmallImage")));
            this.ribbonOrbMenuItem4.Text = "ribbonOrbMenuItem4";
            // 
            // ribbonOrbMenuItem5
            // 
            this.ribbonOrbMenuItem5.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonOrbMenuItem5.Image = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem5.Image")));
            this.ribbonOrbMenuItem5.LargeImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem5.LargeImage")));
            this.ribbonOrbMenuItem5.Name = "ribbonOrbMenuItem5";
            this.ribbonOrbMenuItem5.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem5.SmallImage")));
            this.ribbonOrbMenuItem5.Text = "ribbonOrbMenuItem5";
            // 
            // ribbonOrbMenuItem6
            // 
            this.ribbonOrbMenuItem6.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonOrbMenuItem6.Image = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem6.Image")));
            this.ribbonOrbMenuItem6.LargeImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem6.LargeImage")));
            this.ribbonOrbMenuItem6.Name = "ribbonOrbMenuItem6";
            this.ribbonOrbMenuItem6.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem6.SmallImage")));
            this.ribbonOrbMenuItem6.Text = "ribbonOrbMenuItem6";
            // 
            // ribbonSeparator1
            // 
            this.ribbonSeparator1.Name = "ribbonSeparator1";
            // 
            // ribbonOrbMenuItem7
            // 
            this.ribbonOrbMenuItem7.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonOrbMenuItem7.Image = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem7.Image")));
            this.ribbonOrbMenuItem7.LargeImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem7.LargeImage")));
            this.ribbonOrbMenuItem7.Name = "ribbonOrbMenuItem7";
            this.ribbonOrbMenuItem7.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem7.SmallImage")));
            this.ribbonOrbMenuItem7.Text = "ribbonOrbMenuItem7";
            // 
            // ribbonOrbMenuItem8
            // 
            this.ribbonOrbMenuItem8.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonOrbMenuItem8.Image = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem8.Image")));
            this.ribbonOrbMenuItem8.LargeImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem8.LargeImage")));
            this.ribbonOrbMenuItem8.Name = "ribbonOrbMenuItem8";
            this.ribbonOrbMenuItem8.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem8.SmallImage")));
            this.ribbonOrbMenuItem8.Text = "ribbonOrbMenuItem8";
            // 
            // ribbonOrbRecentItem1
            // 
            this.ribbonOrbRecentItem1.Image = ((System.Drawing.Image)(resources.GetObject("ribbonOrbRecentItem1.Image")));
            this.ribbonOrbRecentItem1.LargeImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbRecentItem1.LargeImage")));
            this.ribbonOrbRecentItem1.Name = "ribbonOrbRecentItem1";
            this.ribbonOrbRecentItem1.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbRecentItem1.SmallImage")));
            this.ribbonOrbRecentItem1.Text = "ribbonOrbRecentItem1";
            // 
            // ribbonOrbRecentItem2
            // 
            this.ribbonOrbRecentItem2.Image = ((System.Drawing.Image)(resources.GetObject("ribbonOrbRecentItem2.Image")));
            this.ribbonOrbRecentItem2.LargeImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbRecentItem2.LargeImage")));
            this.ribbonOrbRecentItem2.Name = "ribbonOrbRecentItem2";
            this.ribbonOrbRecentItem2.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbRecentItem2.SmallImage")));
            this.ribbonOrbRecentItem2.Text = "ribbonOrbRecentItem2";
            // 
            // ribbonOrbRecentItem3
            // 
            this.ribbonOrbRecentItem3.Image = ((System.Drawing.Image)(resources.GetObject("ribbonOrbRecentItem3.Image")));
            this.ribbonOrbRecentItem3.LargeImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbRecentItem3.LargeImage")));
            this.ribbonOrbRecentItem3.Name = "ribbonOrbRecentItem3";
            this.ribbonOrbRecentItem3.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbRecentItem3.SmallImage")));
            this.ribbonOrbRecentItem3.Text = "ribbonOrbRecentItem3";
            // 
            // panel1
            // 
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 144);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(944, 282);
            this.panel1.TabIndex = 1;
            // 
            // frmMainDemo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(944, 426);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.ribbon1);
            this.KeyPreview = true;
            this.Name = "frmMainDemo";
            this.Text = "frmMainDemo";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmMainDemo_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private Ribbon ribbon1;
        private RibbonTab ribbonTab1;
        private RibbonTab ribbonTab2;
        private RibbonOrbMenuItem ribbonOrbMenuItem1;
        private RibbonOrbMenuItem ribbonOrbMenuItem2;
        private RibbonOrbMenuItem ribbonOrbMenuItem3;
        private RibbonOrbMenuItem ribbonOrbMenuItem4;
        private RibbonOrbMenuItem ribbonOrbMenuItem5;
        private RibbonOrbMenuItem ribbonOrbMenuItem6;
        private RibbonSeparator ribbonSeparator1;
        private RibbonOrbMenuItem ribbonOrbMenuItem7;
        private RibbonOrbMenuItem ribbonOrbMenuItem8;
        private RibbonButton ribbonButton15;
        private RibbonButton ribbonButton16;
        private RibbonButton ribbonButton17;
        private RibbonSeparator ribbonSeparator2;
        private RibbonButton ribbonButton18;
        private RibbonButton ribbonButton19;
        private RibbonOrbMenuItem ribbonOrbMenuItem9;
        private RibbonOrbMenuItem ribbonOrbMenuItem10;
        private RibbonOrbMenuItem ribbonOrbMenuItem11;
        private RibbonOrbMenuItem ribbonOrbMenuItem12;
        private RibbonOrbRecentItem ribbonOrbRecentItem1;
        private RibbonOrbRecentItem ribbonOrbRecentItem2;
        private RibbonOrbRecentItem ribbonOrbRecentItem3;
        private RibbonPanel ribbonPanel3;
        private RibbonButton btForm1;
        private RibbonButton btForm2;
        private RibbonButton btForm3;
        private Panel panel1;
        private RibbonPanel ribbonPanel_OrbStyle;
        private RibbonPanel ribbonPanel_Theme;
    }
}