﻿using System.Windows.Forms;

namespace RibbonDemo
{
    public partial class RightToLeftForm : Form
    {
        public RightToLeftForm()
        {
            InitializeComponent();
        }
    }
}
